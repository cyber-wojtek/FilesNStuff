bass source /home/$USER/.profile

if status is-interactive
    # Commands to run in interactive sessions can go here
end
